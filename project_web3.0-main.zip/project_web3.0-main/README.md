# Krypt - Web 3.0 Blockchain Application
![Krypt](https://i.ibb.co/DVF4tNW/image.png)

### [🌟 Become a top 1% Next.js 13 developer in only one course](https://jsmastery.pro/next13)
### [🚀 Land your dream programming job in 6 months](https://jsmastery.pro/masterclass)

## Introduction
This is a code repository for the corresponding video tutorial.

Using Web 3.0 methodologies, Solidity and Metamask you'll learn how to build a your first real Web 3.0 Application - from start to finish.

Project created in collaboration with Enyel Sequeira: 
Portfolio - https://www.enyelsequeira.com
E-mail - enyelsequeira1994@gmail.com
Want me to cover the project you've created? Send me an e-mail 👌

## Launch your development career with project-based coaching - https://www.jsmastery.pro
